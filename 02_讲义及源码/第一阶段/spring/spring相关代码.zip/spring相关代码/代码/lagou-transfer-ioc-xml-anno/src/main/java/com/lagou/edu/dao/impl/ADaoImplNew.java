package com.lagou.edu.dao.impl;

import com.lagou.edu.pojo.A;
import org.springframework.stereotype.Repository;

/**
 * @author 应癫
 */
@Repository
public class ADaoImplNew extends BaseDaoImpl<A> {

}
