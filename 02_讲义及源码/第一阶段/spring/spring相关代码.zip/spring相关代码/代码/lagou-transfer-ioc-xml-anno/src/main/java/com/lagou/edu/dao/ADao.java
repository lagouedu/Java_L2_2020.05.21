package com.lagou.edu.dao;

import com.lagou.edu.pojo.A;

/**
 * @author 应癫
 */
public interface ADao {

    A queryById(int id) throws Exception;
}
