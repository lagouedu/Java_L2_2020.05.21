package com.lagou.edu.dao;

import com.lagou.edu.pojo.B;

/**
 * @author 应癫
 */
public interface BDao {

    B queryById(int id) throws Exception;
}
